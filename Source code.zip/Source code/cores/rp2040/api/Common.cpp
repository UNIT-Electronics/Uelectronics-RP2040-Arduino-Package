#include "../../../ArduinoCore-API/api/Common.cpp"
